# Future Vision — Supabase connected V2

Files: index.html, admin.html, setup.html, supabase-config.js, SUPABASE_ADMIN_SETUP.sql, ADMIN_SETUP.txt, icons.

Before publishing the admin panel, run SUPABASE_ADMIN_SETUP.sql in Supabase SQL Editor and create a private admin user under Authentication -> Users.

The customer site reads active products from `public.products` and inserts orders into `public.orders`.
The admin panel uses Supabase Auth and can add/edit/delete products, update stock, and read/update orders.

Only the Supabase publishable key belongs in the browser. Never use `sb_secret_...` or a legacy service_role key in client-side files.

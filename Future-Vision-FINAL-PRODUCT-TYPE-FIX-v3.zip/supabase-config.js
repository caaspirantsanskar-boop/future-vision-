// Future Vision Supabase configuration
// Project URL is already set. Your Publishable key is saved in this browser only.
window.FUTURE_VISION_SUPABASE_URL = "https://yrklbuxsetbciumsvyte.supabase.co";
window.FUTURE_VISION_SUPABASE_PUBLISHABLE_KEY = localStorage.getItem("futureVisionSupabasePublishableKey") || "";
